package com.cyriacdomini.wikidegrees;

public class WikipediaSearchResponse{
  int ns;
  String title;
  String snippet;
  long size;
  long wordcount;
  String timestamp;
}
